# GitHub Integration Guide for GX Infrastructure Documentation

## Overview

This guide explains how to push all migration documentation, audit reports, and scripts to your GitHub repository.

---

## Prerequisites

1. GitHub account with repository access
2. Git installed on your server
3. GitHub Personal Access Token (for HTTPS) or SSH key (for SSH)

---

## Option 1: Using Personal Access Token (Recommended for Beginners)

### Step 1: Create a Personal Access Token

1. Go to GitHub → Settings → Developer settings → Personal access tokens → Tokens (classic)
2. Click "Generate new token (classic)"
3. Set expiration (e.g., 90 days)
4. Select scopes: `repo` (full control of private repositories)
5. Click "Generate token"
6. **COPY THE TOKEN NOW** - you won't see it again!

### Step 2: Clone or Initialize Repository

```bash
# SSH to VPS-1
ssh root@72.60.210.201

# Create documentation directory
mkdir -p /root/gx-documentation
cd /root/gx-documentation

# Clone existing repository (replace with your repo URL)
git clone https://github.com/YOUR_USERNAME/YOUR_REPO.git .

# Or if starting fresh, initialize:
git init
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
```

### Step 3: Configure Git

```bash
git config --global user.email "your-email@example.com"
git config --global user.name "Your Name"

# Store credentials (so you don't have to enter token every time)
git config --global credential.helper store
```

### Step 4: Copy Documentation Files

```bash
# Create directory structure
mkdir -p /root/gx-documentation/{migration-plans,audit-reports,backup-scripts,runbooks}

# Copy migration plan
cp /mnt/user-data/outputs/GX-Blockchain-Enterprise-Migration-Plan-v2.md /root/gx-documentation/migration-plans/

# Copy backup scripts
cp /root/backup-scripts/*.sh /root/gx-documentation/backup-scripts/
cp /root/backup-scripts/*.md /root/gx-documentation/backup-scripts/

# Copy audit reports (if available)
cp /root/infrastructure-audit-*.tar.gz /root/gx-documentation/audit-reports/ 2>/dev/null || true
```

### Step 5: Commit and Push

```bash
cd /root/gx-documentation

# Stage all files
git add -A

# Check what will be committed
git status

# Commit
git commit -m "Add HA migration plan and backup scripts - Dec 2025"

# Push (first time - you'll be prompted for username and token)
git push -u origin main

# When prompted:
# Username: YOUR_GITHUB_USERNAME
# Password: YOUR_PERSONAL_ACCESS_TOKEN (not your GitHub password!)
```

---

## Option 2: Using SSH Key (More Secure)

### Step 1: Generate SSH Key

```bash
ssh-keygen -t ed25519 -C "your-email@example.com"
# Press Enter for default location
# Enter passphrase (optional)

# Display the public key
cat ~/.ssh/id_ed25519.pub
```

### Step 2: Add SSH Key to GitHub

1. Copy the output of `cat ~/.ssh/id_ed25519.pub`
2. Go to GitHub → Settings → SSH and GPG keys → New SSH key
3. Paste the key and save

### Step 3: Clone Using SSH

```bash
# Use SSH URL instead of HTTPS
git clone git@github.com:YOUR_USERNAME/YOUR_REPO.git /root/gx-documentation
```

### Step 4: Push (no password needed)

```bash
cd /root/gx-documentation
git add -A
git commit -m "Your commit message"
git push origin main
```

---

## Quick Commands Reference

```bash
# Check repository status
git status

# View commit history
git log --oneline -10

# Pull latest changes
git pull origin main

# Create a new branch
git checkout -b feature/new-docs

# Switch branches
git checkout main

# Discard local changes
git checkout -- filename

# View remote URL
git remote -v
```

---

## Recommended Repository Structure

```
gx-infrastructure-docs/
├── README.md                           # Project overview
├── migration-plans/
│   ├── GX-Blockchain-Enterprise-Migration-Plan-v2.md
│   └── GX-Blockchain-HA-Migration-Plan.md
├── audit-reports/
│   ├── infrastructure-audit-20251211.tar.gz
│   └── audit-summary.md
├── backup-scripts/
│   ├── README.md
│   ├── 00-setup-ssh-keys.sh
│   ├── 01-setup-gdrive-backup.sh
│   ├── 02-gx-full-backup.sh
│   ├── 03-setup-automated-backups.sh
│   ├── 04-verify-backup-system.sh
│   ├── 05-multiserver-backup.sh
│   ├── 06-verify-backup-completeness.sh
│   └── 07-github-sync.sh
├── runbooks/
│   ├── incident-response.md
│   ├── disaster-recovery.md
│   └── maintenance-procedures.md
├── architecture/
│   ├── current-state.md
│   ├── target-state.md
│   └── network-diagram.md
└── CHANGELOG.md
```

---

## Sample README.md for Your Repo

```markdown
# GX Blockchain Infrastructure

Infrastructure documentation and operational guides for GX Coin Blockchain Platform.

## Quick Links

- [Migration Plan v2.0](migration-plans/GX-Blockchain-Enterprise-Migration-Plan-v2.md)
- [Backup Scripts](backup-scripts/README.md)

## Infrastructure

| Server | IP | Role |
|--------|-----|------|
| VPS-1 | 72.60.210.201 | MainNet Primary |
| VPS-2 | 72.61.116.210 | K3s Worker |
| VPS-3 | 72.61.81.3 | K3s Master |
| VPS-4 | 217.196.51.190 | DevNet/TestNet |
| VPS-5 | 195.35.36.174 | Partner/Website |

## Recent Changes

- 2025-12-11: Created comprehensive HA migration plan
- 2025-12-11: Implemented multi-server backup to Google Drive
```

---

## Automating GitHub Sync

Add to crontab for automatic documentation sync:

```bash
# Edit crontab
crontab -e

# Add this line to sync daily at midnight
0 0 * * * cd /root/gx-documentation && git add -A && git commit -m "Auto-sync $(date +\%Y-\%m-\%d)" && git push origin main 2>/dev/null || true
```

---

## Troubleshooting

### "Permission denied (publickey)"
- Your SSH key isn't added to GitHub
- Run `ssh -T git@github.com` to test

### "Authentication failed"
- Using HTTPS? Use Personal Access Token, not password
- Token may have expired - generate a new one

### "Repository not found"
- Check the URL is correct
- Ensure you have access to the repository
- Check if repo is private and you're authenticated

### "Updates were rejected"
- Someone else pushed changes
- Run `git pull origin main` first, then push again
