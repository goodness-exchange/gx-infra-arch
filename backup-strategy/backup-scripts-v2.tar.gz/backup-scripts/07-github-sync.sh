#!/bin/bash
#===============================================================================
# GX BLOCKCHAIN - GITHUB DOCUMENTATION SYNC
#===============================================================================
# Purpose: Push migration documentation to GitHub
#===============================================================================

echo "============================================================"
echo "GX BLOCKCHAIN - GITHUB DOCUMENTATION SYNC"
echo "============================================================"
echo ""

# Check if git is installed
if ! command -v git &> /dev/null; then
    echo "Installing git..."
    dnf install -y git || apt-get install -y git
fi

echo "This script will help you push documentation to GitHub."
echo ""

#-------------------------------------------------------------------------------
# Step 1: Configure Git (if needed)
#-------------------------------------------------------------------------------
echo "=== Step 1: Git Configuration ==="

# Check if git is configured
if [ -z "$(git config --global user.email)" ]; then
    echo "Git is not configured. Please provide your details:"
    read -p "Enter your email (used for commits): " GIT_EMAIL
    read -p "Enter your name: " GIT_NAME
    
    git config --global user.email "$GIT_EMAIL"
    git config --global user.name "$GIT_NAME"
    echo "✅ Git configured"
else
    echo "✅ Git already configured as: $(git config --global user.name) <$(git config --global user.email)>"
fi
echo ""

#-------------------------------------------------------------------------------
# Step 2: Setup Repository
#-------------------------------------------------------------------------------
echo "=== Step 2: Repository Setup ==="
echo ""
echo "Please provide your GitHub repository details:"
echo "(Example: https://github.com/username/gx-infrastructure-docs)"
echo ""
read -p "Enter GitHub repository URL: " REPO_URL

if [ -z "$REPO_URL" ]; then
    echo "ERROR: Repository URL is required"
    exit 1
fi

# Create documentation directory
DOC_DIR="/root/gx-documentation"
mkdir -p "$DOC_DIR"
cd "$DOC_DIR"

# Check if repo already cloned
if [ -d ".git" ]; then
    echo "Repository already exists, pulling latest..."
    git pull origin main || git pull origin master
else
    echo "Cloning repository..."
    git clone "$REPO_URL" temp_clone
    mv temp_clone/.git .
    mv temp_clone/* . 2>/dev/null || true
    rm -rf temp_clone
fi
echo ""

#-------------------------------------------------------------------------------
# Step 3: Create Documentation Structure
#-------------------------------------------------------------------------------
echo "=== Step 3: Creating Documentation Structure ==="

mkdir -p "$DOC_DIR"/{migration-plans,audit-reports,backup-scripts,runbooks,architecture}

# Copy migration plans
if [ -f "/root/backups/GX-Blockchain-Enterprise-Migration-Plan-v2.md" ]; then
    cp /root/backups/GX-Blockchain-Enterprise-Migration-Plan-v2.md "$DOC_DIR/migration-plans/"
fi

if [ -f "/mnt/user-data/outputs/GX-Blockchain-Enterprise-Migration-Plan-v2.md" ]; then
    cp /mnt/user-data/outputs/GX-Blockchain-Enterprise-Migration-Plan-v2.md "$DOC_DIR/migration-plans/"
fi

# Copy backup scripts
cp /root/backup-scripts/*.sh "$DOC_DIR/backup-scripts/" 2>/dev/null || true
cp /root/backup-scripts/*.md "$DOC_DIR/backup-scripts/" 2>/dev/null || true

# Copy audit reports
cp /root/infrastructure-audit-*.tar.gz "$DOC_DIR/audit-reports/" 2>/dev/null || true

echo "✅ Documentation structure created"
echo ""

#-------------------------------------------------------------------------------
# Step 4: Create README
#-------------------------------------------------------------------------------
echo "=== Step 4: Creating README ==="

cat > "$DOC_DIR/README.md" << 'EOF'
# GX Blockchain Infrastructure Documentation

This repository contains infrastructure documentation, migration plans, and operational runbooks for the GX Blockchain platform.

## Repository Structure

```
├── migration-plans/     # HA migration planning documents
├── audit-reports/       # Infrastructure audit archives
├── backup-scripts/      # Backup and restore scripts
├── runbooks/           # Operational procedures
└── architecture/       # Architecture diagrams and docs
```

## Quick Links

- [Migration Plan v2](migration-plans/GX-Blockchain-Enterprise-Migration-Plan-v2.md)
- [Backup Scripts](backup-scripts/README.md)

## Infrastructure Overview

| Server | IP | Role |
|--------|-----|------|
| VPS-1 | 72.60.210.201 | MainNet Primary - Fabric, Frontend, Backend |
| VPS-2 | 72.61.116.210 | K3s Worker |
| VPS-3 | 72.61.81.3 | K3s Master |
| VPS-4 | 217.196.51.190 | K3s Master - TestNet/DevNet |
| VPS-5 | 195.35.36.174 | Partner Server - Website |

## Key Documents

### Migration Plans
- Enterprise Migration Plan v2.0 - Comprehensive HA migration with industry best practices

### Backup System
- Multi-server backup to Google Drive
- Automated daily/weekly/monthly backups
- Pre-migration snapshots

## Changelog

| Date | Change | Author |
|------|--------|--------|
| 2025-12-11 | Initial documentation structure | Infrastructure Team |
| 2025-12-11 | Added Enterprise Migration Plan v2.0 | Infrastructure Team |
| 2025-12-11 | Added multi-server backup scripts | Infrastructure Team |

## Contact

For infrastructure issues, contact the DevOps team.
EOF

echo "✅ README created"
echo ""

#-------------------------------------------------------------------------------
# Step 5: Commit and Push
#-------------------------------------------------------------------------------
echo "=== Step 5: Commit and Push ==="

cd "$DOC_DIR"
git add -A

echo ""
echo "Files staged for commit:"
git status --short
echo ""

read -p "Enter commit message (default: 'Update infrastructure documentation'): " COMMIT_MSG
COMMIT_MSG=${COMMIT_MSG:-"Update infrastructure documentation"}

git commit -m "$COMMIT_MSG"

echo ""
echo "Pushing to GitHub..."
echo "You may be prompted for authentication."
echo ""
echo "If using HTTPS, you'll need a Personal Access Token (not password)."
echo "Create one at: https://github.com/settings/tokens"
echo ""

git push origin main || git push origin master

echo ""
echo "============================================================"
echo "GITHUB SYNC COMPLETE!"
echo "============================================================"
echo ""
echo "Documentation has been pushed to:"
echo "  $REPO_URL"
echo ""
echo "Local documentation directory: $DOC_DIR"
echo ""
echo "To update in the future:"
echo "  cd $DOC_DIR"
echo "  git add -A"
echo "  git commit -m 'Your message'"
echo "  git push"
echo ""
