#!/bin/bash
#===============================================================================
# GX BLOCKCHAIN - BACKUP SYSTEM VERIFICATION
#===============================================================================
# Purpose: Verify backup system is properly configured and working
#===============================================================================

echo "=========================================="
echo "GX BACKUP SYSTEM VERIFICATION"
echo "=========================================="
echo "Date: $(date)"
echo ""

PASS=0
FAIL=0

check() {
    if [ $1 -eq 0 ]; then
        echo "✅ $2"
        ((PASS++))
    else
        echo "❌ $2"
        ((FAIL++))
    fi
}

# Check rclone
echo "=== Checking rclone ==="
command -v rclone &> /dev/null
check $? "rclone installed"

rclone version &> /dev/null
check $? "rclone working"
echo ""

# Check Google Drive connection
echo "=== Checking Google Drive Connection ==="
if rclone lsd gdrive-gx: &> /dev/null; then
    check 0 "Connected to Google Drive"
    
    # Check folders exist
    rclone lsd gdrive-gx:GX-Infrastructure-Backups/ &> /dev/null
    check $? "Backup folder exists"
    
    # Check upload capability
    echo "test" > /tmp/verify-test.txt
    rclone copy /tmp/verify-test.txt gdrive-gx:GX-Infrastructure-Backups/ &> /dev/null
    check $? "Upload capability"
    rclone delete gdrive-gx:GX-Infrastructure-Backups/verify-test.txt &> /dev/null 2>&1
    rm /tmp/verify-test.txt
else
    check 1 "Connected to Google Drive"
fi
echo ""

# Check backup scripts
echo "=== Checking Backup Scripts ==="
[ -f /root/backup-scripts/gx-full-backup.sh ]
check $? "Main backup script exists"

[ -x /root/backup-scripts/gx-full-backup.sh ]
check $? "Backup script is executable"
echo ""

# Check directories
echo "=== Checking Directories ==="
[ -d /root/backups ]
check $? "Local backup directory exists"

[ -d /root/backup-logs ]
check $? "Log directory exists"
echo ""

# Check cron
echo "=== Checking Automated Backups ==="
crontab -l 2>/dev/null | grep -q "gx-full-backup"
check $? "Cron job configured"
echo ""

# Check disk space
echo "=== Checking Disk Space ==="
DISK_USAGE=$(df / | tail -1 | awk '{print $5}' | sed 's/%//')
if [ "$DISK_USAGE" -lt 80 ]; then
    check 0 "Disk usage acceptable ($DISK_USAGE%)"
else
    check 1 "Disk usage high ($DISK_USAGE%)"
fi
echo ""

# Check kubectl access
echo "=== Checking Kubernetes Access ==="
kubectl get nodes &> /dev/null
check $? "kubectl working"
echo ""

# Check Docker access
echo "=== Checking Docker Access ==="
docker ps &> /dev/null
check $? "docker working"
echo ""

# List recent backups
echo "=== Recent Backups ==="
echo "Local backups:"
ls -lht /root/backups/*.tar.gz 2>/dev/null | head -5 || echo "  No local backups found"
echo ""

echo "Google Drive backups (last 5):"
rclone ls gdrive-gx:GX-Infrastructure-Backups/ 2>/dev/null | head -10 || echo "  Cannot list remote backups"
echo ""

# Summary
echo "=========================================="
echo "VERIFICATION SUMMARY"
echo "=========================================="
echo "Passed: $PASS"
echo "Failed: $FAIL"
echo ""

if [ $FAIL -eq 0 ]; then
    echo "✅ All checks passed! Backup system is ready."
else
    echo "⚠️  Some checks failed. Please review and fix issues."
fi
echo ""
