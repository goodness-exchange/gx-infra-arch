#!/bin/bash
#===============================================================================
# GX BLOCKCHAIN - MULTI-SERVER COMPREHENSIVE BACKUP
#===============================================================================
# Purpose: Complete backup of ALL 5 servers to Google Drive
# Run on: VPS-1 (72.60.210.201) - Connects to all other servers via SSH
# Requirement: SSH key-based authentication to all servers
#===============================================================================

set -e

# Configuration
BACKUP_DATE=$(date +%Y%m%d-%H%M%S)
BACKUP_NAME="gx-multiserver-backup-$BACKUP_DATE"
BACKUP_DIR="/root/backups/temp/$BACKUP_NAME"
LOG_FILE="/root/backup-logs/backup-$BACKUP_DATE.log"
GDRIVE_REMOTE="gdrive-gx"
GDRIVE_PATH="GX-Infrastructure-Backups"

# Server Configuration
declare -A SERVERS
SERVERS=(
    ["VPS1"]="72.60.210.201"
    ["VPS2"]="72.61.116.210"
    ["VPS3"]="72.61.81.3"
    ["VPS4"]="217.196.51.190"
    ["VPS5"]="195.35.36.174"
)

# Server roles for reference
declare -A SERVER_ROLES
SERVER_ROLES=(
    ["VPS1"]="MainNet Primary - All Fabric Docker, Frontend, Backend"
    ["VPS2"]="K3s Worker - Idle"
    ["VPS3"]="K3s Master - No Docker"
    ["VPS4"]="K3s Master - TestNet/DevNet"
    ["VPS5"]="Partner Server - Partner Peer, Website"
)

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

#-------------------------------------------------------------------------------
# Logging
#-------------------------------------------------------------------------------
log() {
    local level=$1
    shift
    local message="$@"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    case $level in
        INFO)  echo -e "${GREEN}[INFO]${NC} $message" ;;
        WARN)  echo -e "${YELLOW}[WARN]${NC} $message" ;;
        ERROR) echo -e "${RED}[ERROR]${NC} $message" ;;
        HEADER) echo -e "${BLUE}[====]${NC} $message" ;;
    esac
    
    echo "[$timestamp] [$level] $message" >> "$LOG_FILE"
}

#-------------------------------------------------------------------------------
# Check SSH connectivity to all servers
#-------------------------------------------------------------------------------
check_ssh_connectivity() {
    log HEADER "Checking SSH connectivity to all servers"
    
    local all_ok=true
    for server_name in "${!SERVERS[@]}"; do
        local ip="${SERVERS[$server_name]}"
        if ssh -o ConnectTimeout=5 -o BatchMode=yes root@$ip "echo ok" &>/dev/null; then
            log INFO "$server_name ($ip): SSH OK"
        else
            log ERROR "$server_name ($ip): SSH FAILED"
            all_ok=false
        fi
    done
    
    if [ "$all_ok" = false ]; then
        log ERROR "Cannot connect to all servers. Please setup SSH keys first."
        log INFO "Run: ssh-copy-id root@<server-ip> for each server"
        exit 1
    fi
    echo ""
}

#-------------------------------------------------------------------------------
# Initialize backup
#-------------------------------------------------------------------------------
init_backup() {
    echo "============================================================"
    echo "GX BLOCKCHAIN - MULTI-SERVER COMPREHENSIVE BACKUP"
    echo "============================================================"
    echo "Backup ID: $BACKUP_NAME"
    echo "Date: $(date)"
    echo "============================================================"
    echo ""
    
    mkdir -p "$BACKUP_DIR"/{VPS1,VPS2,VPS3,VPS4,VPS5}
    mkdir -p "$BACKUP_DIR"/kubernetes
    mkdir -p /root/backup-logs
    
    log INFO "Backup initialized: $BACKUP_NAME"
    
    # Create server inventory
    cat > "$BACKUP_DIR/SERVER-INVENTORY.txt" << EOF
GX BLOCKCHAIN SERVER INVENTORY
==============================
Backup Date: $(date)

VPS1 (72.60.210.201) - ${SERVER_ROLES[VPS1]}
VPS2 (72.61.116.210) - ${SERVER_ROLES[VPS2]}
VPS3 (72.61.81.3)    - ${SERVER_ROLES[VPS3]}
VPS4 (217.196.51.190) - ${SERVER_ROLES[VPS4]}
VPS5 (195.35.36.174)  - ${SERVER_ROLES[VPS5]}

EOF
}

#-------------------------------------------------------------------------------
# Backup Kubernetes (cluster-wide from VPS1)
#-------------------------------------------------------------------------------
backup_kubernetes_cluster() {
    log HEADER "Backing up Kubernetes Cluster (all nodes)"
    
    local K8S_DIR="$BACKUP_DIR/kubernetes"
    
    # Cluster info
    log INFO "Cluster nodes:"
    kubectl get nodes -o wide | tee "$K8S_DIR/nodes.txt"
    kubectl get nodes -o yaml > "$K8S_DIR/nodes.yaml"
    
    # All namespaces with resources
    NAMESPACES=$(kubectl get namespaces -o jsonpath='{.items[*].metadata.name}')
    
    for ns in $NAMESPACES; do
        log INFO "Backing up namespace: $ns"
        mkdir -p "$K8S_DIR/$ns"
        
        kubectl get all -n $ns -o yaml > "$K8S_DIR/$ns/all-resources.yaml" 2>/dev/null || true
        kubectl get secrets -n $ns -o yaml > "$K8S_DIR/$ns/secrets.yaml" 2>/dev/null || true
        kubectl get configmaps -n $ns -o yaml > "$K8S_DIR/$ns/configmaps.yaml" 2>/dev/null || true
        kubectl get pvc -n $ns -o yaml > "$K8S_DIR/$ns/pvc.yaml" 2>/dev/null || true
        kubectl get svc -n $ns -o yaml > "$K8S_DIR/$ns/services.yaml" 2>/dev/null || true
        kubectl get ingress -n $ns -o yaml > "$K8S_DIR/$ns/ingress.yaml" 2>/dev/null || true
    done
    
    # Cluster-wide resources
    kubectl get pv -o yaml > "$K8S_DIR/persistent-volumes.yaml" 2>/dev/null || true
    kubectl get storageclass -o yaml > "$K8S_DIR/storageclasses.yaml" 2>/dev/null || true
    kubectl get clusterroles -o yaml > "$K8S_DIR/clusterroles.yaml" 2>/dev/null || true
    kubectl get clusterrolebindings -o yaml > "$K8S_DIR/clusterrolebindings.yaml" 2>/dev/null || true
    
    log INFO "✅ Kubernetes cluster backup complete"
    echo ""
}

#-------------------------------------------------------------------------------
# Backup individual server
#-------------------------------------------------------------------------------
backup_server() {
    local SERVER_NAME=$1
    local SERVER_IP=$2
    local SERVER_DIR="$BACKUP_DIR/$SERVER_NAME"
    
    log HEADER "Backing up $SERVER_NAME ($SERVER_IP)"
    
    mkdir -p "$SERVER_DIR"/{system,docker,apps,configs}
    
    # Create remote backup script
    cat > /tmp/remote-backup-$SERVER_NAME.sh << 'REMOTE_SCRIPT'
#!/bin/bash
BACKUP_TMP="/tmp/gx-backup-$$"
mkdir -p $BACKUP_TMP

echo "=== System Information ==="
hostname > $BACKUP_TMP/hostname.txt
uname -a > $BACKUP_TMP/uname.txt
df -h > $BACKUP_TMP/disk-usage.txt
free -h > $BACKUP_TMP/memory.txt
cat /etc/os-release > $BACKUP_TMP/os-release.txt 2>/dev/null || true
ip addr > $BACKUP_TMP/ip-addresses.txt
ss -tlnp > $BACKUP_TMP/listening-ports.txt
ps aux > $BACKUP_TMP/processes.txt
crontab -l > $BACKUP_TMP/crontab.txt 2>/dev/null || true
cat /etc/hosts > $BACKUP_TMP/hosts.txt

echo "=== Docker Information ==="
if command -v docker &> /dev/null; then
    docker ps -a > $BACKUP_TMP/docker-containers.txt 2>/dev/null || true
    docker images > $BACKUP_TMP/docker-images.txt 2>/dev/null || true
    docker volume ls > $BACKUP_TMP/docker-volumes.txt 2>/dev/null || true
    docker network ls > $BACKUP_TMP/docker-networks.txt 2>/dev/null || true
    
    # Export running container info
    for container in $(docker ps -q 2>/dev/null); do
        name=$(docker inspect --format='{{.Name}}' $container | sed 's/\///')
        docker inspect $container > $BACKUP_TMP/docker-inspect-$name.json 2>/dev/null || true
    done
    
    # Backup docker-compose files if they exist
    find /home -name "docker-compose*.yml" -o -name "docker-compose*.yaml" 2>/dev/null | while read f; do
        cp "$f" $BACKUP_TMP/ 2>/dev/null || true
    done
    
    echo "Docker: YES" > $BACKUP_TMP/docker-status.txt
else
    echo "Docker: NOT INSTALLED" > $BACKUP_TMP/docker-status.txt
fi

echo "=== K3s Information ==="
if command -v kubectl &> /dev/null; then
    kubectl get nodes -o wide > $BACKUP_TMP/k3s-nodes.txt 2>/dev/null || true
    echo "K3s: YES" > $BACKUP_TMP/k3s-status.txt
else
    echo "K3s: NOT INSTALLED" > $BACKUP_TMP/k3s-status.txt
fi

echo "=== Configuration Files ==="
# Copy important configs
cp /etc/rancher/k3s/k3s.yaml $BACKUP_TMP/k3s-config.yaml 2>/dev/null || true
cp /etc/docker/daemon.json $BACKUP_TMP/docker-daemon.json 2>/dev/null || true

# Application directories check
ls -la /home/ > $BACKUP_TMP/home-contents.txt 2>/dev/null || true

# Create tarball of backup
cd /tmp
tar -czf gx-server-backup.tar.gz -C $BACKUP_TMP .
rm -rf $BACKUP_TMP

echo "/tmp/gx-server-backup.tar.gz"
REMOTE_SCRIPT

    # Copy and execute remote script
    log INFO "Collecting system information..."
    scp -q /tmp/remote-backup-$SERVER_NAME.sh root@$SERVER_IP:/tmp/
    ssh root@$SERVER_IP "chmod +x /tmp/remote-backup-$SERVER_NAME.sh && /tmp/remote-backup-$SERVER_NAME.sh"
    
    # Download the backup
    log INFO "Downloading backup from $SERVER_NAME..."
    scp -q root@$SERVER_IP:/tmp/gx-server-backup.tar.gz "$SERVER_DIR/system-backup.tar.gz"
    
    # Extract for inspection
    tar -xzf "$SERVER_DIR/system-backup.tar.gz" -C "$SERVER_DIR/system/"
    
    # Cleanup remote
    ssh root@$SERVER_IP "rm -f /tmp/remote-backup-$SERVER_NAME.sh /tmp/gx-server-backup.tar.gz"
    
    log INFO "✅ $SERVER_NAME backup complete"
    echo ""
}

#-------------------------------------------------------------------------------
# Backup VPS1 specific (Fabric Docker, Databases)
#-------------------------------------------------------------------------------
backup_vps1_specific() {
    log HEADER "Backing up VPS1 Specific Data (Fabric, Databases)"
    
    local VPS1_DIR="$BACKUP_DIR/VPS1"
    mkdir -p "$VPS1_DIR"/{fabric-docker,databases,apps}
    
    # Fabric Docker containers
    log INFO "Backing up Fabric Docker data..."
    
    # Export Fabric crypto from Docker volumes
    if docker ps 2>/dev/null | grep -q orderer; then
        log INFO "Found Fabric Docker containers"
        
        # Backup orderer production data
        for i in 0 1 2 3 4; do
            CONTAINER="orderer${i}.ordererorg.prod.goodness.exchange"
            if docker ps -q -f name=$CONTAINER 2>/dev/null | grep -q .; then
                log INFO "  Backing up $CONTAINER ledger..."
                docker cp $CONTAINER:/var/hyperledger/production "$VPS1_DIR/fabric-docker/orderer${i}-production" 2>/dev/null || true
            fi
        done
        
        # Backup peer production data
        for org in org1 org2; do
            for peer in 0 1; do
                CONTAINER="peer${peer}.${org}.prod.goodness.exchange"
                if docker ps -q -f name=$CONTAINER 2>/dev/null | grep -q .; then
                    log INFO "  Backing up $CONTAINER ledger..."
                    docker cp $CONTAINER:/var/hyperledger/production "$VPS1_DIR/fabric-docker/peer${peer}-${org}-production" 2>/dev/null || true
                fi
            done
        done
    fi
    
    # PostgreSQL dump (MainNet)
    log INFO "Backing up PostgreSQL databases..."
    PG_POD=$(kubectl get pods -n backend-mainnet -l app=postgres -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
    if [ -n "$PG_POD" ]; then
        kubectl exec -n backend-mainnet $PG_POD -- pg_dumpall -U postgres > "$VPS1_DIR/databases/postgres-mainnet-full.sql" 2>/dev/null || true
        log INFO "  ✅ PostgreSQL MainNet dump complete"
    fi
    
    # PostgreSQL TestNet
    PG_POD_TEST=$(kubectl get pods -n backend-testnet -l app=postgres -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
    if [ -n "$PG_POD_TEST" ]; then
        kubectl exec -n backend-testnet $PG_POD_TEST -- pg_dumpall -U postgres > "$VPS1_DIR/databases/postgres-testnet-full.sql" 2>/dev/null || true
        log INFO "  ✅ PostgreSQL TestNet dump complete"
    fi
    
    # Fabric CA PostgreSQL (Docker)
    if docker ps 2>/dev/null | grep -q "postgres.ca"; then
        docker exec postgres.ca pg_dumpall -U postgres > "$VPS1_DIR/databases/postgres-fabric-ca.sql" 2>/dev/null || true
        log INFO "  ✅ Fabric CA PostgreSQL dump complete"
    fi
    
    # Redis dump
    log INFO "Backing up Redis..."
    REDIS_POD=$(kubectl get pods -n backend-mainnet -l app=redis -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
    if [ -n "$REDIS_POD" ]; then
        kubectl exec -n backend-mainnet $REDIS_POD -- redis-cli BGSAVE 2>/dev/null || true
        sleep 3
        kubectl cp backend-mainnet/$REDIS_POD:/data/dump.rdb "$VPS1_DIR/databases/redis-mainnet.rdb" 2>/dev/null || true
        log INFO "  ✅ Redis dump complete"
    fi
    
    # CouchDB state
    log INFO "Backing up CouchDB state databases..."
    mkdir -p "$VPS1_DIR/databases/couchdb"
    for i in 0 1 2 3; do
        PORT=$((5984 + i * 1000))
        if curl -s http://localhost:$PORT/_all_dbs 2>/dev/null | grep -q "\["; then
            DBS=$(curl -s http://localhost:$PORT/_all_dbs | jq -r '.[]' 2>/dev/null || echo "")
            for db in $DBS; do
                if [[ "$db" != "_"* ]]; then
                    curl -s "http://localhost:$PORT/$db/_all_docs?include_docs=true" > "$VPS1_DIR/databases/couchdb/couchdb${i}-${db}.json" 2>/dev/null || true
                fi
            done
            log INFO "  ✅ CouchDB${i} backup complete"
        fi
    done
    
    # Application source/configs
    log INFO "Backing up application configurations..."
    if [ -d "/home/sugxcoin/prod-blockchain" ]; then
        # Backend env
        cp /home/sugxcoin/prod-blockchain/gx-protocol-backend/.env* "$VPS1_DIR/apps/" 2>/dev/null || true
        # Frontend env
        cp /home/sugxcoin/prod-blockchain/gx-wallet-frontend/.env* "$VPS1_DIR/apps/" 2>/dev/null || true
        # Fabric network configs
        cp /home/sugxcoin/prod-blockchain/gx-coin-fabric/network/*.yaml "$VPS1_DIR/apps/" 2>/dev/null || true
        cp /home/sugxcoin/prod-blockchain/gx-coin-fabric/network/*.yml "$VPS1_DIR/apps/" 2>/dev/null || true
        # Crypto materials
        if [ -d "/home/sugxcoin/prod-blockchain/gx-coin-fabric/network/organizations" ]; then
            tar -czf "$VPS1_DIR/fabric-docker/crypto-materials.tar.gz" -C /home/sugxcoin/prod-blockchain/gx-coin-fabric/network organizations 2>/dev/null || true
            log INFO "  ✅ Crypto materials backup complete"
        fi
    fi
    
    log INFO "✅ VPS1 specific backup complete"
    echo ""
}

#-------------------------------------------------------------------------------
# Backup VPS5 specific (Partner peer, Website)
#-------------------------------------------------------------------------------
backup_vps5_specific() {
    log HEADER "Backing up VPS5 Specific Data (Partner, Website)"
    
    local VPS5_DIR="$BACKUP_DIR/VPS5"
    mkdir -p "$VPS5_DIR"/{partner,website}
    
    # Partner peer data
    log INFO "Backing up Partner Peer..."
    ssh root@${SERVERS[VPS5]} << 'REMOTE_CMD'
cd /tmp
mkdir -p partner-backup

# Partner peer Docker data
if docker ps 2>/dev/null | grep -q partner; then
    docker ps -a | grep partner > partner-backup/partner-containers.txt
    for container in $(docker ps -q --filter "name=partner" 2>/dev/null); do
        name=$(docker inspect --format='{{.Name}}' $container | sed 's/\///')
        docker inspect $container > partner-backup/docker-$name.json 2>/dev/null || true
    done
fi

# Website files
if [ -d "/var/www/gxcoin.money" ]; then
    tar -czf partner-backup/website-gxcoin.tar.gz -C /var/www gxcoin.money 2>/dev/null || true
fi

# Apache/Nginx configs
cp -r /etc/httpd/conf* partner-backup/ 2>/dev/null || true
cp -r /etc/nginx partner-backup/ 2>/dev/null || true

tar -czf partner-backup.tar.gz partner-backup
rm -rf partner-backup
REMOTE_CMD

    scp -q root@${SERVERS[VPS5]}:/tmp/partner-backup.tar.gz "$VPS5_DIR/"
    tar -xzf "$VPS5_DIR/partner-backup.tar.gz" -C "$VPS5_DIR/"
    ssh root@${SERVERS[VPS5]} "rm -f /tmp/partner-backup.tar.gz"
    
    log INFO "✅ VPS5 specific backup complete"
    echo ""
}

#-------------------------------------------------------------------------------
# Create summary and manifest
#-------------------------------------------------------------------------------
create_manifest() {
    log HEADER "Creating backup manifest"
    
    cat > "$BACKUP_DIR/MANIFEST.txt" << EOF
================================================================================
GX BLOCKCHAIN MULTI-SERVER BACKUP MANIFEST
================================================================================
Backup ID: $BACKUP_NAME
Created: $(date)
Created By: $(whoami)@$(hostname)

================================================================================
SERVERS INCLUDED
================================================================================
EOF

    for server_name in VPS1 VPS2 VPS3 VPS4 VPS5; do
        local ip="${SERVERS[$server_name]}"
        local role="${SERVER_ROLES[$server_name]}"
        echo "$server_name ($ip): $role" >> "$BACKUP_DIR/MANIFEST.txt"
        
        # Check what was backed up
        if [ -d "$BACKUP_DIR/$server_name" ]; then
            echo "  Backup size: $(du -sh "$BACKUP_DIR/$server_name" | cut -f1)" >> "$BACKUP_DIR/MANIFEST.txt"
            echo "  Contents:" >> "$BACKUP_DIR/MANIFEST.txt"
            ls -la "$BACKUP_DIR/$server_name"/ 2>/dev/null | sed 's/^/    /' >> "$BACKUP_DIR/MANIFEST.txt"
        fi
        echo "" >> "$BACKUP_DIR/MANIFEST.txt"
    done

    cat >> "$BACKUP_DIR/MANIFEST.txt" << EOF

================================================================================
KUBERNETES CLUSTER
================================================================================
Nodes: $(kubectl get nodes --no-headers 2>/dev/null | wc -l)
Namespaces backed up: $(ls "$BACKUP_DIR/kubernetes" 2>/dev/null | wc -l)
Total K8s backup size: $(du -sh "$BACKUP_DIR/kubernetes" 2>/dev/null | cut -f1)

================================================================================
BACKUP CONTENTS SUMMARY
================================================================================
EOF

    # Calculate sizes
    du -sh "$BACKUP_DIR"/*/ 2>/dev/null >> "$BACKUP_DIR/MANIFEST.txt"
    
    echo "" >> "$BACKUP_DIR/MANIFEST.txt"
    echo "Total backup size: $(du -sh "$BACKUP_DIR" | cut -f1)" >> "$BACKUP_DIR/MANIFEST.txt"
    
    cat >> "$BACKUP_DIR/MANIFEST.txt" << EOF

================================================================================
RESTORE INSTRUCTIONS
================================================================================
1. Download backup from Google Drive
2. Extract: tar -xzvf $BACKUP_NAME.tar.gz
3. Review MANIFEST.txt for contents
4. Restore Kubernetes: kubectl apply -f kubernetes/<namespace>/
5. Restore databases from SQL dumps
6. Restore Docker volumes if needed
7. Verify services are running

================================================================================
EOF

    log INFO "✅ Manifest created"
}

#-------------------------------------------------------------------------------
# Create archive and upload
#-------------------------------------------------------------------------------
create_and_upload() {
    local BACKUP_TYPE=${1:-"manual"}
    
    log HEADER "Creating archive and uploading to Google Drive"
    
    # Create archive
    log INFO "Creating compressed archive..."
    cd /root/backups/temp
    tar -czvf "/root/backups/$BACKUP_NAME.tar.gz" "$BACKUP_NAME" 2>/dev/null
    
    ARCHIVE_SIZE=$(du -h "/root/backups/$BACKUP_NAME.tar.gz" | cut -f1)
    log INFO "Archive created: $BACKUP_NAME.tar.gz ($ARCHIVE_SIZE)"
    
    # Upload
    log INFO "Uploading to Google Drive..."
    if rclone copy "/root/backups/$BACKUP_NAME.tar.gz" "$GDRIVE_REMOTE:$GDRIVE_PATH/$BACKUP_TYPE/" --progress; then
        log INFO "✅ Upload successful!"
        
        # Verify
        if rclone ls "$GDRIVE_REMOTE:$GDRIVE_PATH/$BACKUP_TYPE/$BACKUP_NAME.tar.gz" 2>/dev/null; then
            log INFO "✅ Upload verified in Google Drive"
        fi
    else
        log ERROR "Upload failed!"
        return 1
    fi
    
    # Cleanup temp
    rm -rf "$BACKUP_DIR"
    
    # Keep only last 5 local backups
    cd /root/backups
    ls -t gx-multiserver-backup-*.tar.gz 2>/dev/null | tail -n +6 | xargs -r rm -f
}

#-------------------------------------------------------------------------------
# Main
#-------------------------------------------------------------------------------
main() {
    local BACKUP_TYPE=${1:-"manual"}
    local START_TIME=$(date +%s)
    
    init_backup
    check_ssh_connectivity
    
    # Backup all servers
    backup_kubernetes_cluster
    
    for server_name in VPS1 VPS2 VPS3 VPS4 VPS5; do
        backup_server "$server_name" "${SERVERS[$server_name]}"
    done
    
    # Server-specific detailed backups
    backup_vps1_specific
    backup_vps5_specific
    
    create_manifest
    create_and_upload "$BACKUP_TYPE"
    
    local END_TIME=$(date +%s)
    local DURATION=$((END_TIME - START_TIME))
    
    echo ""
    echo "============================================================"
    echo "MULTI-SERVER BACKUP COMPLETE!"
    echo "============================================================"
    echo ""
    echo "Backup ID: $BACKUP_NAME"
    echo "Duration: $((DURATION / 60)) minutes $((DURATION % 60)) seconds"
    echo "Archive: /root/backups/$BACKUP_NAME.tar.gz ($ARCHIVE_SIZE)"
    echo "Google Drive: $GDRIVE_PATH/$BACKUP_TYPE/"
    echo "Log: $LOG_FILE"
    echo ""
    echo "Servers backed up:"
    for server_name in VPS1 VPS2 VPS3 VPS4 VPS5; do
        echo "  ✅ $server_name (${SERVERS[$server_name]})"
    done
    echo ""
}

# Usage
if [ "$1" == "-h" ] || [ "$1" == "--help" ]; then
    echo "Usage: $0 [backup-type]"
    echo ""
    echo "Backup types: manual, daily, weekly, monthly, pre-migration"
    exit 0
fi

main "$1"
