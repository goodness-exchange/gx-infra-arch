#!/bin/bash
#===============================================================================
# GX BLOCKCHAIN - GOOGLE DRIVE BACKUP SETUP SCRIPT
#===============================================================================
# Purpose: Configure rclone for Google Drive backup
# Account: gxc@handsforeducation.org
# Run on: VPS-1 (72.60.210.201) - Primary backup server
#===============================================================================

set -e

echo "=========================================="
echo "GX BLOCKCHAIN - GOOGLE DRIVE BACKUP SETUP"
echo "=========================================="
echo "Date: $(date)"
echo ""

#-------------------------------------------------------------------------------
# Step 1: Install rclone
#-------------------------------------------------------------------------------
install_rclone() {
    echo "=== Step 1: Installing rclone ==="
    
    if command -v rclone &> /dev/null; then
        echo "✅ rclone already installed: $(rclone version | head -1)"
    else
        echo "Installing rclone..."
        curl -s https://rclone.org/install.sh | bash
        echo "✅ rclone installed: $(rclone version | head -1)"
    fi
    echo ""
}

#-------------------------------------------------------------------------------
# Step 2: Create directories
#-------------------------------------------------------------------------------
create_directories() {
    echo "=== Step 2: Creating backup directories ==="
    
    mkdir -p /root/.config/rclone
    mkdir -p /root/backups/{daily,weekly,monthly,pre-migration,temp}
    mkdir -p /root/backup-scripts
    mkdir -p /root/backup-logs
    
    echo "✅ Directories created:"
    echo "   - /root/.config/rclone"
    echo "   - /root/backups/{daily,weekly,monthly,pre-migration,temp}"
    echo "   - /root/backup-scripts"
    echo "   - /root/backup-logs"
    echo ""
}

#-------------------------------------------------------------------------------
# Step 3: Configure rclone (Interactive OAuth)
#-------------------------------------------------------------------------------
configure_rclone_interactive() {
    echo "=== Step 3: Configuring rclone for Google Drive ==="
    echo ""
    echo "You will need to authenticate with Google Drive."
    echo "Account to use: gxc@handsforeducation.org"
    echo ""
    echo "IMPORTANT: Since this is a headless server, you'll need to:"
    echo "1. Run this on a machine with a browser, OR"
    echo "2. Use the remote authorization option"
    echo ""
    
    read -p "Do you have a local machine with a browser to authenticate? (yes/no): " HAS_BROWSER
    
    if [ "$HAS_BROWSER" == "yes" ]; then
        echo ""
        echo "Running rclone config..."
        echo "When prompted:"
        echo "  - Name: gdrive-gx"
        echo "  - Storage: drive (Google Drive)"
        echo "  - Client ID: (leave blank)"
        echo "  - Client Secret: (leave blank)"
        echo "  - Scope: 1 (full access)"
        echo "  - Root folder ID: (leave blank)"
        echo "  - Service account: (leave blank)"
        echo "  - Edit advanced config: n"
        echo "  - Auto config: n (for remote server)"
        echo ""
        rclone config
    else
        echo ""
        echo "=== REMOTE AUTHORIZATION METHOD ==="
        echo ""
        echo "On your LOCAL machine (with browser), run:"
        echo "  rclone authorize \"drive\""
        echo ""
        echo "This will open a browser. Log in with: gxc@handsforeducation.org"
        echo "After authorization, you'll get a token. Copy it."
        echo ""
        read -p "Press Enter when you have the token ready..."
        
        echo ""
        echo "Paste the token below (it's a JSON string starting with {\"access_token\"):"
        read -r TOKEN
        
        # Create config file
        cat > /root/.config/rclone/rclone.conf << EOF
[gdrive-gx]
type = drive
scope = drive
token = $TOKEN
team_drive = 
EOF
        
        echo "✅ Configuration saved to /root/.config/rclone/rclone.conf"
    fi
    echo ""
}

#-------------------------------------------------------------------------------
# Step 4: Test connection
#-------------------------------------------------------------------------------
test_connection() {
    echo "=== Step 4: Testing Google Drive connection ==="
    
    if rclone lsd gdrive-gx: 2>/dev/null; then
        echo "✅ Successfully connected to Google Drive!"
        echo ""
        echo "Current folders in drive:"
        rclone lsd gdrive-gx: 2>/dev/null | head -10
    else
        echo "❌ Connection failed. Please check configuration."
        echo "Run 'rclone config' to reconfigure."
        exit 1
    fi
    echo ""
}

#-------------------------------------------------------------------------------
# Step 5: Create backup folder structure in Google Drive
#-------------------------------------------------------------------------------
create_gdrive_folders() {
    echo "=== Step 5: Creating folder structure in Google Drive ==="
    
    # Create main backup folder
    rclone mkdir gdrive-gx:GX-Infrastructure-Backups 2>/dev/null || true
    
    # Create subfolders
    rclone mkdir gdrive-gx:GX-Infrastructure-Backups/daily 2>/dev/null || true
    rclone mkdir gdrive-gx:GX-Infrastructure-Backups/weekly 2>/dev/null || true
    rclone mkdir gdrive-gx:GX-Infrastructure-Backups/monthly 2>/dev/null || true
    rclone mkdir gdrive-gx:GX-Infrastructure-Backups/pre-migration 2>/dev/null || true
    rclone mkdir gdrive-gx:GX-Infrastructure-Backups/manual 2>/dev/null || true
    rclone mkdir gdrive-gx:GX-Infrastructure-Backups/disaster-recovery 2>/dev/null || true
    
    echo "✅ Google Drive folder structure created:"
    rclone lsd gdrive-gx:GX-Infrastructure-Backups/
    echo ""
}

#-------------------------------------------------------------------------------
# Step 6: Verify setup
#-------------------------------------------------------------------------------
verify_setup() {
    echo "=== Step 6: Verifying setup ==="
    
    # Create test file
    echo "GX Backup Test - $(date)" > /tmp/gx-backup-test.txt
    
    # Upload test file
    if rclone copy /tmp/gx-backup-test.txt gdrive-gx:GX-Infrastructure-Backups/; then
        echo "✅ Test upload successful!"
        
        # Verify file exists
        if rclone ls gdrive-gx:GX-Infrastructure-Backups/gx-backup-test.txt 2>/dev/null; then
            echo "✅ Test file verified in Google Drive"
            
            # Clean up test file
            rclone delete gdrive-gx:GX-Infrastructure-Backups/gx-backup-test.txt 2>/dev/null || true
            echo "✅ Test file cleaned up"
        fi
    else
        echo "❌ Test upload failed"
        exit 1
    fi
    
    rm -f /tmp/gx-backup-test.txt
    echo ""
}

#-------------------------------------------------------------------------------
# Main execution
#-------------------------------------------------------------------------------
main() {
    echo "Starting Google Drive backup setup..."
    echo ""
    
    install_rclone
    create_directories
    configure_rclone_interactive
    test_connection
    create_gdrive_folders
    verify_setup
    
    echo "=========================================="
    echo "SETUP COMPLETE!"
    echo "=========================================="
    echo ""
    echo "Google Drive backup is now configured."
    echo ""
    echo "Next steps:"
    echo "1. Run the full backup script: /root/backup-scripts/gx-full-backup.sh"
    echo "2. Set up automated backups with cron"
    echo ""
    echo "Quick test command:"
    echo "  rclone ls gdrive-gx:GX-Infrastructure-Backups/"
    echo ""
}

# Run main function
main
