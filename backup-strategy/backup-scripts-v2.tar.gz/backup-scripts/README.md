# GX Blockchain Backup System

## Overview

This backup system provides comprehensive backup of all GX blockchain infrastructure to Google Drive.

**Google Drive Account:** gxc@handsforeducation.org

## Quick Start

### Step 1: Setup Google Drive Connection

```bash
# Copy scripts to VPS-1
scp -r backup-scripts root@72.60.210.201:/root/

# SSH to VPS-1
ssh root@72.60.210.201

# Make scripts executable
chmod +x /root/backup-scripts/*.sh

# Run setup script
/root/backup-scripts/01-setup-gdrive-backup.sh
```

### Step 2: Run Initial Backup

```bash
# Run pre-migration backup (recommended before any changes)
/root/backup-scripts/02-gx-full-backup.sh pre-migration
```

### Step 3: Setup Automated Backups

```bash
/root/backup-scripts/03-setup-automated-backups.sh
```

## Scripts

| Script | Purpose |
|--------|---------|
| `01-setup-gdrive-backup.sh` | Configure rclone for Google Drive |
| `02-gx-full-backup.sh` | Run comprehensive backup |
| `03-setup-automated-backups.sh` | Configure cron schedules |

## What Gets Backed Up

### Kubernetes Resources
- All namespaces (fabric, backend-mainnet, etc.)
- Secrets (including crypto materials)
- ConfigMaps
- Deployments, StatefulSets, Services
- PVCs and PVs
- Ingress rules
- Network policies

### Fabric Network
- All CA certificates and keys
- Orderer/Peer crypto materials
- Channel configuration
- Genesis blocks
- Chaincode packages

### Databases
- PostgreSQL (full dump + individual databases)
- Redis (RDB snapshots)
- CouchDB (all state databases)

### Docker
- Volume backups
- docker-compose files
- Container configurations

### Application Configs
- Backend .env files
- Frontend .env files
- System configurations

## Backup Schedule

| Type | Frequency | Retention | Time |
|------|-----------|-----------|------|
| Daily | Every day | 7 days | 2:00 AM |
| Weekly | Sunday | 4 weeks | 3:00 AM |
| Monthly | 1st | 12 months | 4:00 AM |
| Pre-migration | On demand | Permanent | Manual |

## Google Drive Structure

```
GX-Infrastructure-Backups/
├── daily/
│   └── gx-full-backup-YYYYMMDD-HHMMSS.tar.gz
├── weekly/
│   └── gx-full-backup-YYYYMMDD-HHMMSS.tar.gz
├── monthly/
│   └── gx-full-backup-YYYYMMDD-HHMMSS.tar.gz
├── pre-migration/
│   └── gx-full-backup-YYYYMMDD-HHMMSS.tar.gz
├── manual/
│   └── gx-full-backup-YYYYMMDD-HHMMSS.tar.gz
└── disaster-recovery/
```

## Commands

### Run Manual Backup
```bash
/root/backup-scripts/02-gx-full-backup.sh manual
```

### Run Pre-Migration Backup
```bash
/root/backup-scripts/02-gx-full-backup.sh pre-migration
```

### List Backups in Google Drive
```bash
rclone ls gdrive-gx:GX-Infrastructure-Backups/
```

### Download a Backup
```bash
rclone copy gdrive-gx:GX-Infrastructure-Backups/daily/gx-full-backup-XXXX.tar.gz /root/restore/
```

### Check Backup Logs
```bash
# Most recent backup log
ls -lt /root/backup-logs/ | head -5

# View specific log
tail -100 /root/backup-logs/backup-YYYYMMDD-HHMMSS.log

# View cron logs
tail -f /root/backup-logs/cron-daily.log
```

## Restore Procedures

### Full Restore

```bash
# Download backup
rclone copy gdrive-gx:GX-Infrastructure-Backups/pre-migration/gx-full-backup-XXXX.tar.gz /root/restore/

# Extract
cd /root/restore
tar -xzvf gx-full-backup-XXXX.tar.gz

# Restore Kubernetes resources
kubectl apply -f kubernetes/fabric/secrets.yaml
kubectl apply -f kubernetes/fabric/configmaps.yaml
kubectl apply -f kubernetes/fabric/statefulsets.yaml

# Restore PostgreSQL
kubectl exec -i postgres-0 -n backend-mainnet -- psql -U postgres < databases/postgresql/mainnet-full-dump.sql

# Restore Redis
kubectl cp databases/redis/mainnet-dump.rdb backend-mainnet/redis-0:/data/dump.rdb
kubectl exec -n backend-mainnet redis-0 -- redis-cli SHUTDOWN NOSAVE
# Pod will restart and load dump.rdb
```

### Restore Individual Components

```bash
# Restore only secrets
kubectl apply -f kubernetes/fabric/secrets.yaml

# Restore only PostgreSQL
kubectl exec -i postgres-0 -n backend-mainnet -- psql -U postgres -d gx_database < databases/postgresql/mainnet-gx_database.dump

# Restore CouchDB state
# (Requires manual procedure - contact admin)
```

## Troubleshooting

### rclone Connection Issues
```bash
# Test connection
rclone lsd gdrive-gx:

# Re-authenticate
rclone config reconnect gdrive-gx:

# Check config
cat ~/.config/rclone/rclone.conf
```

### Backup Failures
```bash
# Check disk space
df -h

# Check memory
free -h

# Check logs
tail -100 /root/backup-logs/backup-*.log | grep -i error
```

### Large Backup Size
```bash
# Check backup size before upload
du -sh /root/backups/temp/*

# Check Google Drive usage
rclone about gdrive-gx:
```

## Security Notes

1. **Credentials**: Google Drive credentials are stored in `~/.config/rclone/rclone.conf`
2. **Encryption**: Backups are NOT encrypted by default. For production, consider:
   - Using rclone crypt backend
   - Encrypting archive with gpg before upload
3. **Access Control**: Only root has access to backup scripts and credentials
4. **Retention**: Old backups are automatically deleted per retention policy

## Contact

For backup issues or restore assistance, contact the infrastructure team.
