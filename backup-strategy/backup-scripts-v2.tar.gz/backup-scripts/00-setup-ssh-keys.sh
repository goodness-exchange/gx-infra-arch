#!/bin/bash
#===============================================================================
# GX BLOCKCHAIN - SSH KEY SETUP FOR MULTI-SERVER BACKUP
#===============================================================================
# Purpose: Setup passwordless SSH from VPS1 to all other servers
# Run on: VPS-1 (72.60.210.201)
#===============================================================================

echo "============================================================"
echo "SSH KEY SETUP FOR MULTI-SERVER BACKUP"
echo "============================================================"
echo ""

# Server IPs
SERVERS=(
    "72.61.116.210"   # VPS2
    "72.61.81.3"      # VPS3
    "217.196.51.190"  # VPS4
    "195.35.36.174"   # VPS5
)

SERVER_NAMES=(
    "VPS2"
    "VPS3"
    "VPS4"
    "VPS5"
)

# Check if SSH key exists
if [ ! -f ~/.ssh/id_ed25519 ]; then
    echo "=== Generating SSH key ==="
    ssh-keygen -t ed25519 -f ~/.ssh/id_ed25519 -N "" -C "gx-backup@vps1"
    echo "✅ SSH key generated"
else
    echo "✅ SSH key already exists"
fi
echo ""

# Display public key
echo "=== Your Public Key ==="
cat ~/.ssh/id_ed25519.pub
echo ""

# Copy key to each server
echo "=== Copying SSH key to servers ==="
echo "You will be prompted for the root password for each server."
echo ""

for i in "${!SERVERS[@]}"; do
    ip="${SERVERS[$i]}"
    name="${SERVER_NAMES[$i]}"
    
    echo "Setting up $name ($ip)..."
    
    # Check if already accessible
    if ssh -o ConnectTimeout=5 -o BatchMode=yes root@$ip "echo ok" &>/dev/null; then
        echo "  ✅ $name: Already accessible (key already installed)"
    else
        echo "  Copying key to $name..."
        ssh-copy-id -o StrictHostKeyChecking=no root@$ip
        
        # Verify
        if ssh -o ConnectTimeout=5 -o BatchMode=yes root@$ip "echo ok" &>/dev/null; then
            echo "  ✅ $name: Key installed successfully"
        else
            echo "  ❌ $name: Failed to install key"
        fi
    fi
    echo ""
done

# Test all connections
echo "=== Testing All Connections ==="
ALL_OK=true
for i in "${!SERVERS[@]}"; do
    ip="${SERVERS[$i]}"
    name="${SERVER_NAMES[$i]}"
    
    if ssh -o ConnectTimeout=5 -o BatchMode=yes root@$ip "hostname" &>/dev/null; then
        HOSTNAME=$(ssh -o ConnectTimeout=5 root@$ip "hostname" 2>/dev/null)
        echo "✅ $name ($ip): Connected - $HOSTNAME"
    else
        echo "❌ $name ($ip): Connection failed"
        ALL_OK=false
    fi
done
echo ""

if [ "$ALL_OK" = true ]; then
    echo "============================================================"
    echo "SSH SETUP COMPLETE!"
    echo "============================================================"
    echo ""
    echo "All servers are now accessible without password."
    echo ""
    echo "You can now run the multi-server backup:"
    echo "  /root/backup-scripts/05-multiserver-backup.sh pre-migration"
    echo ""
else
    echo "============================================================"
    echo "SSH SETUP INCOMPLETE"
    echo "============================================================"
    echo ""
    echo "Some servers could not be configured."
    echo "Please manually copy the SSH key to failed servers:"
    echo ""
    echo "  ssh-copy-id root@<server-ip>"
    echo ""
fi
