#!/bin/bash
#===============================================================================
# GX BLOCKCHAIN - HEADLESS GOOGLE DRIVE SETUP
#===============================================================================
# Purpose: Setup rclone for headless servers (no browser)
# Use this if you can't run interactive setup
#===============================================================================

echo "=========================================="
echo "HEADLESS GOOGLE DRIVE SETUP"
echo "=========================================="
echo ""
echo "This script will guide you through setting up Google Drive"
echo "access on a headless server."
echo ""
echo "Account: gxc@handsforeducation.org"
echo ""

# Install rclone
echo "=== Step 1: Installing rclone ==="
if ! command -v rclone &> /dev/null; then
    curl -s https://rclone.org/install.sh | bash
fi
echo "✅ rclone installed: $(rclone version | head -1)"
echo ""

# Create directories
mkdir -p /root/.config/rclone
mkdir -p /root/backups/{daily,weekly,monthly,pre-migration,temp}
mkdir -p /root/backup-scripts
mkdir -p /root/backup-logs

echo "=== Step 2: Authorization ==="
echo ""
echo "Since this is a headless server, you need to authorize from another machine."
echo ""
echo "On your LOCAL computer (with a web browser), run:"
echo ""
echo "  1. Install rclone: https://rclone.org/install/"
echo "  2. Run this command:"
echo ""
echo "     rclone authorize \"drive\""
echo ""
echo "  3. A browser will open - log in with: gxc@handsforeducation.org"
echo "  4. Password: Tech1@Osm!um76"
echo "  5. After authorization, rclone will display a token"
echo "  6. Copy the ENTIRE token (starts with {\"access_token\"...)"
echo ""
echo "=========================================="
echo ""

read -p "Press Enter when you have the token ready..."

echo ""
echo "Paste the token below (single line, starting with {\"access_token\"):"
echo ""
read -r TOKEN

if [ -z "$TOKEN" ]; then
    echo "ERROR: No token provided"
    exit 1
fi

# Create rclone config
cat > /root/.config/rclone/rclone.conf << EOF
[gdrive-gx]
type = drive
scope = drive
token = $TOKEN
team_drive = 
EOF

echo ""
echo "=== Step 3: Testing connection ==="

if rclone lsd gdrive-gx: 2>/dev/null; then
    echo "✅ Successfully connected to Google Drive!"
    echo ""
    echo "Creating backup folder structure..."
    
    rclone mkdir gdrive-gx:GX-Infrastructure-Backups 2>/dev/null || true
    rclone mkdir gdrive-gx:GX-Infrastructure-Backups/daily 2>/dev/null || true
    rclone mkdir gdrive-gx:GX-Infrastructure-Backups/weekly 2>/dev/null || true
    rclone mkdir gdrive-gx:GX-Infrastructure-Backups/monthly 2>/dev/null || true
    rclone mkdir gdrive-gx:GX-Infrastructure-Backups/pre-migration 2>/dev/null || true
    rclone mkdir gdrive-gx:GX-Infrastructure-Backups/manual 2>/dev/null || true
    
    echo "✅ Folder structure created"
    echo ""
    echo "Testing upload..."
    echo "GX Backup Test - $(date)" > /tmp/test-backup.txt
    rclone copy /tmp/test-backup.txt gdrive-gx:GX-Infrastructure-Backups/
    rclone delete gdrive-gx:GX-Infrastructure-Backups/test-backup.txt 2>/dev/null || true
    rm /tmp/test-backup.txt
    
    echo "✅ Upload test successful!"
    echo ""
    echo "=========================================="
    echo "SETUP COMPLETE!"
    echo "=========================================="
    echo ""
    echo "Google Drive is now configured."
    echo ""
    echo "Run backup now with:"
    echo "  /root/backup-scripts/gx-full-backup.sh pre-migration"
    echo ""
else
    echo "❌ Connection failed. Please check the token and try again."
    echo ""
    echo "Debug: Run 'rclone config show' to see current config"
    exit 1
fi
