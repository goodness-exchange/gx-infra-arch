#!/bin/bash
#===============================================================================
# GX BLOCKCHAIN - BACKUP VERIFICATION & AUDIT
#===============================================================================
# Purpose: Verify backup completeness and integrity
# Checks both local backup and Google Drive upload
#===============================================================================

echo "============================================================"
echo "GX BLOCKCHAIN - BACKUP VERIFICATION & AUDIT"
echo "============================================================"
echo "Date: $(date)"
echo ""

# Find most recent backup
LATEST_LOCAL=$(ls -t /root/backups/gx-*backup-*.tar.gz 2>/dev/null | head -1)
LATEST_MULTISERVER=$(ls -t /root/backups/gx-multiserver-backup-*.tar.gz 2>/dev/null | head -1)

# Counters
PASS=0
FAIL=0
WARN=0

check_pass() { echo -e "✅ $1"; ((PASS++)); }
check_fail() { echo -e "❌ $1"; ((FAIL++)); }
check_warn() { echo -e "⚠️  $1"; ((WARN++)); }

#-------------------------------------------------------------------------------
# Section 1: Check Local Backup
#-------------------------------------------------------------------------------
echo "=== Section 1: Local Backup Check ==="
echo ""

if [ -n "$LATEST_LOCAL" ]; then
    check_pass "Local backup found: $(basename $LATEST_LOCAL)"
    echo "    Size: $(du -h "$LATEST_LOCAL" | cut -f1)"
    echo "    Date: $(stat -c %y "$LATEST_LOCAL" | cut -d. -f1)"
    
    # Extract and check contents
    TEMP_DIR="/tmp/backup-verify-$$"
    mkdir -p $TEMP_DIR
    
    echo ""
    echo "Extracting backup for verification..."
    tar -tzf "$LATEST_LOCAL" > $TEMP_DIR/contents.txt 2>/dev/null
    
    TOTAL_FILES=$(wc -l < $TEMP_DIR/contents.txt)
    echo "    Total files in backup: $TOTAL_FILES"
else
    check_fail "No local backup found"
fi
echo ""

#-------------------------------------------------------------------------------
# Section 2: Check Google Drive Backups
#-------------------------------------------------------------------------------
echo "=== Section 2: Google Drive Backup Check ==="
echo ""

if command -v rclone &> /dev/null; then
    if rclone lsd gdrive-gx: &>/dev/null; then
        check_pass "Google Drive connection working"
        
        echo ""
        echo "Backups in Google Drive:"
        for folder in manual daily weekly monthly pre-migration; do
            COUNT=$(rclone ls gdrive-gx:GX-Infrastructure-Backups/$folder/ 2>/dev/null | wc -l)
            SIZE=$(rclone size gdrive-gx:GX-Infrastructure-Backups/$folder/ 2>/dev/null | grep "Total size" | awk '{print $3, $4}')
            echo "    $folder: $COUNT files ($SIZE)"
        done
        
        echo ""
        echo "Most recent backups:"
        rclone ls gdrive-gx:GX-Infrastructure-Backups/ --max-depth 2 2>/dev/null | sort -k2 | tail -5
    else
        check_fail "Cannot connect to Google Drive"
    fi
else
    check_fail "rclone not installed"
fi
echo ""

#-------------------------------------------------------------------------------
# Section 3: Check What SHOULD Be Backed Up
#-------------------------------------------------------------------------------
echo "=== Section 3: Infrastructure Inventory Check ==="
echo ""

echo "Checking what should be backed up vs what exists..."
echo ""

# Server connectivity
echo "Server Connectivity:"
declare -A SERVERS
SERVERS=(
    ["VPS1"]="72.60.210.201"
    ["VPS2"]="72.61.116.210"
    ["VPS3"]="72.61.81.3"
    ["VPS4"]="217.196.51.190"
    ["VPS5"]="195.35.36.174"
)

for server_name in "${!SERVERS[@]}"; do
    ip="${SERVERS[$server_name]}"
    if ping -c 1 -W 2 $ip &>/dev/null; then
        check_pass "$server_name ($ip): Reachable"
    else
        check_warn "$server_name ($ip): Not reachable"
    fi
done
echo ""

# Kubernetes cluster
echo "Kubernetes Cluster:"
if kubectl get nodes &>/dev/null; then
    NODE_COUNT=$(kubectl get nodes --no-headers | wc -l)
    check_pass "Kubernetes accessible: $NODE_COUNT nodes"
    
    # Check critical namespaces
    CRITICAL_NS="fabric backend-mainnet backend-testnet"
    for ns in $CRITICAL_NS; do
        if kubectl get namespace $ns &>/dev/null; then
            POD_COUNT=$(kubectl get pods -n $ns --no-headers 2>/dev/null | wc -l)
            check_pass "Namespace $ns: $POD_COUNT pods"
        else
            check_fail "Namespace $ns: NOT FOUND"
        fi
    done
else
    check_fail "Kubernetes not accessible"
fi
echo ""

# Docker containers
echo "Docker Containers (VPS1):"
if docker ps &>/dev/null; then
    FABRIC_CONTAINERS=$(docker ps --format '{{.Names}}' | grep -E "orderer|peer|couchdb|ca" | wc -l)
    check_pass "Fabric containers running: $FABRIC_CONTAINERS"
    
    # List critical containers
    echo "    Critical containers:"
    docker ps --format '{{.Names}}' | grep -E "orderer|peer" | while read c; do
        echo "      - $c"
    done
else
    check_warn "Docker not accessible on this server"
fi
echo ""

# Databases
echo "Databases:"
# PostgreSQL
PG_POD=$(kubectl get pods -n backend-mainnet -l app=postgres -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)
if [ -n "$PG_POD" ]; then
    DB_COUNT=$(kubectl exec -n backend-mainnet $PG_POD -- psql -U postgres -t -c "SELECT count(*) FROM pg_database WHERE datistemplate = false" 2>/dev/null | tr -d ' ')
    check_pass "PostgreSQL MainNet: $DB_COUNT databases"
else
    check_warn "PostgreSQL MainNet: Not found"
fi

# Redis
REDIS_POD=$(kubectl get pods -n backend-mainnet -l app=redis -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)
if [ -n "$REDIS_POD" ]; then
    KEY_COUNT=$(kubectl exec -n backend-mainnet $REDIS_POD -- redis-cli DBSIZE 2>/dev/null | awk '{print $2}')
    check_pass "Redis MainNet: $KEY_COUNT keys"
else
    check_warn "Redis MainNet: Not found"
fi

# CouchDB
COUCH_COUNT=$(kubectl get pods -n fabric -l app=couchdb --no-headers 2>/dev/null | wc -l)
if [ "$COUCH_COUNT" -gt 0 ]; then
    check_pass "CouchDB: $COUCH_COUNT instances in K8s"
fi

# Docker CouchDB
DOCKER_COUCH=$(docker ps --format '{{.Names}}' 2>/dev/null | grep -c couchdb || echo "0")
if [ "$DOCKER_COUCH" -gt 0 ]; then
    check_pass "CouchDB: $DOCKER_COUCH Docker containers"
fi
echo ""

#-------------------------------------------------------------------------------
# Section 4: Verify Backup Contents
#-------------------------------------------------------------------------------
echo "=== Section 4: Backup Contents Verification ==="
echo ""

if [ -n "$LATEST_LOCAL" ] && [ -f "$TEMP_DIR/contents.txt" ]; then
    echo "Checking backup contains critical data..."
    echo ""
    
    # Check for Kubernetes resources
    if grep -q "kubernetes/" $TEMP_DIR/contents.txt; then
        K8S_FILES=$(grep -c "kubernetes/" $TEMP_DIR/contents.txt)
        check_pass "Kubernetes resources: $K8S_FILES files"
    else
        check_fail "Kubernetes resources: NOT FOUND in backup"
    fi
    
    # Check for secrets
    if grep -q "secrets.yaml" $TEMP_DIR/contents.txt; then
        SECRET_FILES=$(grep -c "secrets.yaml" $TEMP_DIR/contents.txt)
        check_pass "Kubernetes secrets: $SECRET_FILES files"
    else
        check_fail "Kubernetes secrets: NOT FOUND in backup"
    fi
    
    # Check for fabric namespace
    if grep -q "kubernetes/fabric/" $TEMP_DIR/contents.txt; then
        check_pass "Fabric namespace: Backed up"
    else
        check_fail "Fabric namespace: NOT FOUND in backup"
    fi
    
    # Check for databases
    if grep -q "postgres.*\.sql\|databases/postgresql" $TEMP_DIR/contents.txt; then
        check_pass "PostgreSQL dumps: Found"
    else
        check_warn "PostgreSQL dumps: NOT FOUND in backup"
    fi
    
    if grep -q "redis.*\.rdb\|databases/redis" $TEMP_DIR/contents.txt; then
        check_pass "Redis dumps: Found"
    else
        check_warn "Redis dumps: NOT FOUND in backup"
    fi
    
    if grep -q "couchdb.*\.json\|databases/couchdb" $TEMP_DIR/contents.txt; then
        check_pass "CouchDB exports: Found"
    else
        check_warn "CouchDB exports: NOT FOUND in backup"
    fi
    
    # Check for multi-server (if multiserver backup)
    if grep -q "VPS1\|VPS2\|VPS3\|VPS4\|VPS5" $TEMP_DIR/contents.txt; then
        for vps in VPS1 VPS2 VPS3 VPS4 VPS5; do
            if grep -q "$vps/" $TEMP_DIR/contents.txt; then
                check_pass "$vps: Included in backup"
            else
                check_warn "$vps: NOT in backup"
            fi
        done
    else
        check_warn "Multi-server backup: This appears to be single-server backup"
    fi
fi
echo ""

# Cleanup
rm -rf $TEMP_DIR 2>/dev/null

#-------------------------------------------------------------------------------
# Summary
#-------------------------------------------------------------------------------
echo "============================================================"
echo "VERIFICATION SUMMARY"
echo "============================================================"
echo ""
echo "Passed: $PASS"
echo "Failed: $FAIL"
echo "Warnings: $WARN"
echo ""

if [ $FAIL -eq 0 ] && [ $WARN -eq 0 ]; then
    echo "✅ All checks passed! Backup appears complete."
elif [ $FAIL -eq 0 ]; then
    echo "⚠️  Backup completed with warnings. Review items above."
else
    echo "❌ Backup has failures. Please investigate and re-run backup."
fi

echo ""
echo "============================================================"
echo "RECOMMENDATIONS"
echo "============================================================"

if [ -z "$LATEST_MULTISERVER" ]; then
    echo "• Run multi-server backup for complete coverage:"
    echo "  /root/backup-scripts/05-multiserver-backup.sh pre-migration"
fi

if [ $WARN -gt 0 ] || [ $FAIL -gt 0 ]; then
    echo "• Review backup logs: /root/backup-logs/"
    echo "• Check server connectivity"
    echo "• Verify database accessibility"
fi

echo ""
