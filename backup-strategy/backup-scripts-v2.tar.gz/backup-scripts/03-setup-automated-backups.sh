#!/bin/bash
#===============================================================================
# GX BLOCKCHAIN - AUTOMATED BACKUP CRON SETUP
#===============================================================================
# Purpose: Configure automated backup schedules
# Run on: VPS-1 (72.60.210.201)
#===============================================================================

set -e

echo "=========================================="
echo "GX BLOCKCHAIN - AUTOMATED BACKUP SETUP"
echo "=========================================="
echo ""

BACKUP_SCRIPT="/root/backup-scripts/gx-full-backup.sh"

# Check if backup script exists
if [ ! -f "$BACKUP_SCRIPT" ]; then
    echo "ERROR: Backup script not found at $BACKUP_SCRIPT"
    echo "Please run the setup script first."
    exit 1
fi

# Make scripts executable
chmod +x /root/backup-scripts/*.sh

# Create cron entries
echo "Setting up automated backup schedules..."
echo ""

# Backup current crontab
crontab -l > /tmp/current_crontab 2>/dev/null || true

# Remove existing GX backup entries
grep -v "gx-full-backup.sh" /tmp/current_crontab > /tmp/new_crontab 2>/dev/null || true

# Add new backup schedules
cat >> /tmp/new_crontab << 'EOF'
# GX Blockchain Automated Backups
# Daily backup at 2:00 AM
0 2 * * * /root/backup-scripts/gx-full-backup.sh daily >> /root/backup-logs/cron-daily.log 2>&1

# Weekly backup on Sunday at 3:00 AM
0 3 * * 0 /root/backup-scripts/gx-full-backup.sh weekly >> /root/backup-logs/cron-weekly.log 2>&1

# Monthly backup on 1st at 4:00 AM
0 4 1 * * /root/backup-scripts/gx-full-backup.sh monthly >> /root/backup-logs/cron-monthly.log 2>&1
EOF

# Install new crontab
crontab /tmp/new_crontab
rm -f /tmp/current_crontab /tmp/new_crontab

echo "✅ Automated backup schedules configured:"
echo ""
echo "Schedule:"
echo "  - Daily:   2:00 AM every day"
echo "  - Weekly:  3:00 AM every Sunday"
echo "  - Monthly: 4:00 AM on 1st of each month"
echo ""
echo "Current crontab:"
crontab -l | grep -E "gx-full-backup|GX Blockchain"
echo ""
echo "Logs will be stored in: /root/backup-logs/"
echo ""
echo "To view backup logs:"
echo "  tail -f /root/backup-logs/cron-daily.log"
echo ""
echo "To manually trigger a backup:"
echo "  /root/backup-scripts/gx-full-backup.sh manual"
echo "  /root/backup-scripts/gx-full-backup.sh pre-migration"
echo ""
